package com.example.youtube;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class BottomSheetFragment extends BottomSheetDialogFragment {

    private TextView title;
    private TextView good_sheet;
    private TextView see_sheet;
    private TextView date_sheet;

    private String position, s_title;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.bottom_sheet_layout, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        title = view.findViewById(R.id.sheet_title);
        good_sheet = view.findViewById(R.id.good_sheet);
        see_sheet = view.findViewById(R.id.see_sheet);
        date_sheet = view.findViewById(R.id.date_sheet);

        Bundle bundle = this.getArguments();
        if(bundle != null){
            bundle = getArguments();
            position = bundle.getString("pos");
            s_title = bundle.getString("title");

            title.setText(s_title);
            int num = Integer.parseInt(position);
            if(num == 0){
                good_sheet.setText("3.6만");
                see_sheet.setText("3,660,562");
                date_sheet.setText("4월 18일");
            }
            else if(num == 1){
                good_sheet.setText("1.8만");
                see_sheet.setText("1,859,649");
                date_sheet.setText("5월 9일");
            }
            else if(num == 2){
                good_sheet.setText("3천");
                see_sheet.setText("55,399");
                date_sheet.setText("4월 25일");
            }
            else if(num == 3){
                good_sheet.setText("6.1천");
                see_sheet.setText("1,026,301");
                date_sheet.setText("4월 20일");
            }
            else if(num == 4){
                good_sheet.setText("361");
                see_sheet.setText("321,671");
                date_sheet.setText("5월 10일");
            }
        }


        view.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
    }
}