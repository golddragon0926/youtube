package com.example.youtube;

public class Item {
    public String bigimage;
    public String smallimage;
    public String title;
    public String name;
    public String see;
    public String date;

    public Item(String bigimage, String smallimage, String title, String name, String see, String date) {
        this.bigimage = bigimage;
        this.smallimage = smallimage;
        this.title = title;
        this.name = name;
        this.see = see;
        this.date = date;
    }

    public String getBigimage() {
        return bigimage;
    }

    public void setBigimage(String bigimage) {
        this.bigimage = bigimage;
    }

    public String getSmallimage() {
        return smallimage;
    }

    public void setSmallimage(String smallimage) {
        this.smallimage = smallimage;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSee() {
        return see;
    }

    public void setSee(String see) {
        this.see = see;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
