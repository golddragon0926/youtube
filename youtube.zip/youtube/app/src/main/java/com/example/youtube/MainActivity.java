package com.example.youtube;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    private ViewPager2 pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setIcon(R.drawable.youtube);
//        getSupportActionBar().setHomeAsUpIndicator(R.drawable.youtube);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("");

        pager = findViewById(R.id.pager);
        ViewPagerAdapter pagerAdapter = new ViewPagerAdapter(this);
        pager.setAdapter(pagerAdapter);

        BottomNavigationView bottomnavi = findViewById(R.id.bottom_navigation);
        bottomnavi.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home_bottom:
                        pager.setCurrentItem(0);
                         return true;

                    case R.id.shorts:
                        pager.setCurrentItem(1);
                        return true;

                    case R.id.goodoc:
                        pager.setCurrentItem(2);
                        return true;

                    case R.id.box:
                        pager.setCurrentItem(3);
                        return true;
                }
                return false;
            }
        });


        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                switch (position){
                    case 0:
                        bottomnavi.getMenu().findItem(R.id.home_bottom).setChecked(true);
                        break;

                    case 1:
                        bottomnavi.getMenu().findItem(R.id.shorts).setChecked(true);
                        break;

                    case 2:
                        bottomnavi.getMenu().findItem(R.id.goodoc).setChecked(true);
                        break;

                    case 3:
                        bottomnavi.getMenu().findItem(R.id.box).setChecked(true);
                        break;
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_top, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.search:
                Toast.makeText(this, "search를 클릭했습니다.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.guest:
                Toast.makeText(this, "guest를 클릭했습니다.", Toast.LENGTH_SHORT).show();
                break;
            default :
                return super.onOptionsItemSelected(item) ;
        }
        return true;
    }
}