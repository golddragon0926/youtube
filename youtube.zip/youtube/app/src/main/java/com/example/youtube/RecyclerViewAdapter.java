package com.example.youtube;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.CustomViewHolder>{
    private ArrayList<Item> item;
    private Context mContext;
    private OnItemClickListener itemClickListener;
    private GradientDrawable drawable;

    public interface OnItemClickListener{
        void onItemClick(View v, int pos, Item item);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        this.itemClickListener = listener;
    }

    public RecyclerViewAdapter(Context context, ArrayList<Item> items) {
        this.item = items;
        this.mContext = context;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.onBind(position, item.get(position));
    }

    @Override
    public int getItemCount() {
        return item.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout layout;
        ImageView big_Image;
        ImageView small_Image;
        TextView title;
        TextView name;
        TextView see;
        TextView date;
        ImageView etc;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            layout = itemView.findViewById(R.id.layout);
            big_Image = itemView.findViewById(R.id.big_image);
            small_Image = itemView.findViewById(R.id.small_image);
            title = itemView.findViewById(R.id.title);
            name = itemView.findViewById(R.id.name);
            see = itemView.findViewById(R.id.see);
            date = itemView.findViewById(R.id.date);
            drawable= (GradientDrawable) itemView.getContext().getDrawable(R.drawable.round);
            etc = itemView.findViewById(R.id.etc);
        }

        public void onBind(int position, Item item) {
            layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(position != RecyclerView.NO_POSITION) {
                        if(itemClickListener != null){
                            itemClickListener.onItemClick(view, position, item);
                        }
                    }
                }
            });
            small_Image.setBackground(drawable);
            small_Image.setClipToOutline(true);

            Glide.with(big_Image.getContext()).load(item.bigimage).into(big_Image);
            Glide.with(small_Image.getContext()).load(item.smallimage).into(small_Image);
            title.setText(item.title);
            name.setText(item.name);
            see.setText(item.see);
            date.setText(item.date);
        }
    }
}