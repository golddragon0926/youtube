package com.example.youtube;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class RecyclerViewFragment<V> extends Fragment{
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private RecyclerViewAdapter adapter;
    private ArrayList<Item> item = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_recyclerview, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.rv);
        layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);

        item.add(new Item("https://i.ytimg.com/vi_webp/h3rKe6DdC18/sddefault.webp","https://yt3.ggpht.com/ytc/AKedOLRkJUDMUwBHNoC1EPLuNVUTKT6k6GVn82SbWOKrNQ=s48-c-k-c0x00ffffff-no-rj", "[토르: 러브 앤 썬더] 티저 예고편", "MarvelKorea", "조회수 313만회", "1일 전"));
        item.add(new Item("https://i.ytimg.com/vi/7Q70_m-59O8/hqdefault.jpg","https://yt3.ggpht.com/ytc/AKedOLRMzwHMolxVA7l0jIP8l1BJG2KhxxA6yfldqkp29A=s48-c-k-c0x00ffffff-no-rj", "[아바타: 물의 길] 티저 예고편", "20th Century Korea", "조회수 112만회", "34분 전"));
        item.add(new Item("https://i.ytimg.com/vi_webp/hYZUwxda-dM/sddefault.webp","https://yt3.ggpht.com/W1yixTvJqZeSAdfqeb2qrSMVShBLBiem9vnkOf0KIKMdBl4n_YBSqQY7zJILJD1qH0MMB3PO-ek=s48-c-k-c0x00ffffff-no-rj", "[그대가 조국] 티저 예고편", "엣나인필름ATNINEFILM", "조회수 4.8만회", "3주 전"));
        item.add(new Item("https://i.ytimg.com/vi_webp/5NlxY-hidkI/sddefault.webp","https://yt3.ggpht.com/XM8pES_WM703S83DjPSAc2NtuMFtHha254_txw4S9c489oGWESK9uAKNbncoVsfaK4dNOPIn=s48-c-k-c0x00ffffff-no-rj", "2022 가장 특별한 여정! [브로커] 티저 예고편", "CJ ENM Movie", "조회수 100만회", "1시간 전"));
        item.add(new Item("https://i.ytimg.com/vi_webp/nIR-XkLVocM/hqdefault.webp","https://yt3.ggpht.com/W1yixTvJqZeSAdfqeb2qrSMVShBLBiem9vnkOf0KIKMdBl4n_YBSqQY7zJILJD1qH0MMB3PO-ek=s88-c-k-c0x00ffffff-no-rj", "[#소년비행2] 티저예고편 공개  | 5월 31일 단독공개", "seezn 시즌", "조회수 5.6만회", "1일 전"));

        adapter = new RecyclerViewAdapter(getContext(), item);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View v, int pos, Item clickItem) {

                Intent intent = new Intent(getContext(), SubActivity.class);
                intent.putExtra("pos", String.valueOf(pos));
                intent.putExtra("title", clickItem.title);
                intent.putExtra("name", clickItem.name);
                intent.putExtra("see", clickItem.see);
                intent.putExtra("date", clickItem.date);
                intent.putExtra("image", clickItem.smallimage);
                startActivity(intent);
            }
        });
    }


}