package com.example.youtube;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import java.util.ArrayList;

public class SubActivity extends AppCompatActivity {

    private androidx.appcompat.widget.Toolbar toolbar;

    private TextView title, name, see, date, letter, goodoc;
    private ImageView imageView;
    private GradientDrawable drawable;
    private Button good_button, bad_button, share_button, box_button, declaration_button, btn_click;

    private BottomSheetFragment bottomSheet;

    private String s_title, s_name, s_see, s_date, image, pos;
    private int position, n_good = 0, n_bad = 0;

    private YouTubePlayerView youTubePlayerView;
    private String videoId;

    private ArrayList<Item> data = new ArrayList<>();
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private RecyclerViewAdapter recyclerViewAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        youTubePlayerView = findViewById(R.id.youtube_player_view);
        getLifecycle().addObserver(youTubePlayerView);

        letter = findViewById(R.id.letter);
        imageView = findViewById(R.id.activity_imageView);
        title = findViewById(R.id.activity_title);
        name = findViewById(R.id.activity_name);
        see = findViewById(R.id.activity_see);
        date = findViewById(R.id.activity_date);
        goodoc = findViewById(R.id.goodoc);
        Button goodoc_button = findViewById(R.id.goodoc_button);

        good_button = findViewById(R.id.good_bt);
        bad_button = findViewById(R.id.bad_bt);
        share_button = findViewById(R.id.share_bt);
        box_button = findViewById(R.id.box_bt);
        declaration_button = findViewById(R.id.declaration_bt);

        btn_click = findViewById(R.id.bottom_sheet_button);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setIcon(R.drawable.youtube);
        getSupportActionBar().setTitle("");


        good_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(n_good == 0) {
                    good_button.setSelected(true);
                    Toast.makeText(SubActivity.this, "좋아요 버튼이 클릭되었습니다.", Toast.LENGTH_SHORT).show();
                    n_good = 1;
                }
                else{
                    good_button.setSelected(false);
                    Toast.makeText(SubActivity.this, "좋아요 버튼이 취소되었습니다.", Toast.LENGTH_SHORT).show();
                    n_good = 0;
                }
            }
        });

        bad_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(n_bad == 0) {
                    bad_button.setSelected(true);
                    Toast.makeText(SubActivity.this, "싫어요 버튼이 클릭되었습니다.", Toast.LENGTH_SHORT).show();
                    n_bad = 1;
                }
                else{
                    bad_button.setSelected(false);
                    Toast.makeText(SubActivity.this, "싫어요 버튼이 취소되었습니다.", Toast.LENGTH_SHORT).show();
                    n_bad = 0;
                }
            }
        });
        share_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SubActivity.this, "공유 버튼이 클릭되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        box_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SubActivity.this, "저장 버튼이 클릭되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        declaration_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SubActivity.this, "신고 버튼이 클릭되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        goodoc_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SubActivity.this, "구독 버튼이 클릭되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        recyclerView = findViewById(R.id.nextRecyclerView);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        data.add(new Item("https://i.ytimg.com/vi/pIVPDilGt7E/hq720.jpg?sqp=-oaymwEcCK4FEIIDSEbyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLBDVOgdZNgTyEDUXdUp522a6cZcVQ","https://yt3.ggpht.com/ytc/AKedOLSGnXjtNPvb7tvKccV2sOdbHzJQCKG_ct3c6ujegg=s68-c-k-c0x00ffffff-no-rj", "토르:러브 앤 썬더 1차 예고편 분석 총정리", "B Man 삐맨", "조회수 39만회", "1일 전"));
        data.add(new Item("https://i.ytimg.com/vi/E_FPhW_aSkU/hq720.jpg?sqp=-oaymwEcCK4FEIIDSEbyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLCmR7316LDi1gcAheg71nl34kRkOw","https://yt3.ggpht.com/ytc/AKedOLQ9YxBcdAGWEpA69QFeVeXrZ4CEM-xlg0V-99tpcA=s68-c-k-c0x00ffffff-no-rj", "제작진조차 빵터진 엔드게임 속 잔망터지는 애드립들", "엔스Ens", "조회수 725만회", "34분 전"));
        data.add(new Item("https://i.ytimg.com/vi/9u7zSkTMdZs/hq720.jpg?sqp=-oaymwEcCK4FEIIDSEbyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDT-9liO4n_DWgUGUa-XANSE0qVmg","https://yt3.ggpht.com/ytc/AKedOLRNRxdhCP0fERB6nE5quk1L4MBBtgnz76-jmINs=s68-c-k-c0x00ffffff-no-rj", "토니피터 Tony&amp;Peter ||  WHAT IF...?", "설기", "조회수 1.5만회", "3주 전"));
        data.add(new Item("https://i.ytimg.com/vi/gTEIqx-KMB0/mqdefault.jpg","https://yt3.ggpht.com/ytc/AKedOLRazU8wT-3ukGdRWQyiJiFrLDqYmvcsX1_gRiFc=s68-c-k-c0x00ffffff-no-rj", "아니 진짜 무슨 이런 개웃긴 영화가 다있냐 ㅋㅋㅋㅋㅋㅋ[영화리뷰][결말포함]", "북부의 왕 Movie Review", "조회수 116만회", "1시간 전"));
        data.add(new Item("https://i.ytimg.com/vi_webp/MYgbuWYkrec/hqdefault.webp","https://yt3.ggpht.com/ytc/AKedOLTtOxZ-jVb7IUXADoPH8dck7tp6XPy7YAxzABEz=s68-c-k-c0x00ffffff-no-rj", "디즈니 플러스 ≪문나이트≫ 1~6화 정주행 줄거리 총정리 요약!", "무비띵크_Movie Think", "조회수 18만회", "1일 전"));

        recyclerViewAdapter = new RecyclerViewAdapter(getApplicationContext(), data);
        recyclerView.setAdapter(recyclerViewAdapter);

        drawable = (GradientDrawable) getApplicationContext().getDrawable(R.drawable.round);

        imageView.setBackground(drawable);
        imageView.setClipToOutline(true);

        Intent intent = getIntent();
        pos = intent.getExtras().getString("pos");
        s_title = intent.getExtras().getString("title");
        s_name = intent.getExtras().getString("name");
        s_see = intent.getExtras().getString("see");
        s_date = intent.getExtras().getString("date");
        image = intent.getExtras().getString("image");

        title.setText(s_title);
        name.setText(s_name);
        see.setText(s_see);
        date.setText(s_date);
        Glide.with(imageView.getContext()).load(image).into(imageView);

        position = Integer.parseInt(pos);

        switch (position) {
            case 0:
                goodoc.setText("구독자 19 만명");
                letter.setText("댓글 • 5,029개");
                videoId = "h3rKe6DdC18";
                break;
            case 1:
                goodoc.setText("구독자 13 만명");
                letter.setText("댓글 • 3,029개");
                videoId = "7Q70_m-59O8";
                break;
            case 2:
                goodoc.setText("구독자 11 만명");
                letter.setText("댓글 • 1,029개");
                videoId = "hYZUwxda-dM";
                break;
            case 3:
                goodoc.setText("구독자 2 만명");
                letter.setText("댓글 • 10,029개");
                videoId = "5NlxY-hidkI";
                break;
            case 4:
                goodoc.setText("구독자 50 만명");
                letter.setText("댓글 • 9,029개");
                videoId = "nIR-XkLVocM";
                break;
        }

        btn_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheet = new BottomSheetFragment();
                Bundle bundle = new Bundle();
                bundle.putString("pos",pos);
                bundle.putString("title",s_title);
                bottomSheet.setArguments(bundle);
                bottomSheet.show(getSupportFragmentManager(), bottomSheet.getTag());
            }
        });

        youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                youTubePlayer.loadVideo(videoId, 0);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_top, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.search:
                Toast.makeText(this, "search를 클릭했습니다.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.guest:
                Toast.makeText(this, "guest를 클릭했습니다.", Toast.LENGTH_SHORT).show();
                break;
            default :
                return super.onOptionsItemSelected(item) ;
        }
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(null != youTubePlayerView) {
            youTubePlayerView.release();
            youTubePlayerView = null;
        }
    }

}